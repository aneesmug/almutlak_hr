<?php
$mailcus->Host = "secure.emailsrvr.com";
$mailcus->Port = 465;
$mailcus->SMTPAuth = true;
$mailcus->SMTPSecure = 'ssl';
$mailcus->Username = "info@mochachino.co";
$mailcus->Password = "MocH#7889";
$mailcus->setFrom('info@mochachino.co', 'Mochachino Co.');
// $mail->addReplyTo('aneesmug2007@yahoo.com', 'Quran From Heart');
?>