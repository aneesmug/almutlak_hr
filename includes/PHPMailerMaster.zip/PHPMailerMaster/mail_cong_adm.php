<?php
$mailadm->Host = "secure.emailsrvr.com";
$mailadm->Port = 465;
$mailadm->SMTPAuth = true;
$mailadm->SMTPSecure = 'ssl';
$mailadm->Username = "info@mochachino.co";
$mailadm->Password = "MocH#7889";
$mailadm->setFrom('info@mochachino.co', 'Mochachino Co.');
// $mail->addReplyTo('aneesmug2007@yahoo.com', 'Quran From Heart');
?>