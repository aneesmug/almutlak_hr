'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'codiepie';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f284';
var svgPathData = 'M442.5 202.9c30.7 0 33.5 53.1-.3 53.1l-10.8 0 0 44.3-26.6 0 0-97.4 37.7 0zM492 352.6C449.9 444.5 370.4 504 268 504 131 504 20 393 20 256S131 8 268 8c97.4 0 172.8 53.7 218.2 138.4L300.2 255.2 492 352.6zm-38.5 12.5l-60.3-30.7c-27.1 44.3-70.4 71.4-122.4 71.4-82.5 0-149.2-66.7-149.2-148.9 0-82.5 66.7-149.2 149.2-149.2 48.4 0 88.9 23.5 116.9 63.4l59.5-34.6C406.5 73.9 342.5 36.5 268 36.5 146.8 36.5 48.5 134.8 48.5 256S146.8 475.5 268 475.5c78.6 0 146.5-42.1 185.5-110.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCodiepie = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;