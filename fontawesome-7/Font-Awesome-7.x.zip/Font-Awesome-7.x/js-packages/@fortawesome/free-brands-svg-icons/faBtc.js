'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'btc';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'f15a';
var svgPathData = 'M310.4 242.6c27.7-14.2 45.4-39.4 41.3-81.3-5.4-57.4-52.5-76.6-114.8-81.9l0-79.4-48.5 0 0 77.2c-12.6 0-25.5 .3-38.4 .6l0-77.8-48.5 0 0 79.4c-17.8 .5-38.6 .3-97.4 0l0 51.7c38.3-.7 58.4-3.1 63 21.4l0 217.4c-2.9 19.5-18.5 16.7-53.3 16.1L4 443.7c88.5 0 97.4 .3 97.4 .3l0 68 48.5 0 0-67.1c13.2 .3 26.2 .3 38.4 .3l0 66.7 48.5 0 0-68c81.3-4.4 135.6-24.9 142.9-101.5 5.7-61.4-23.3-88.9-69.3-99.9zM150.8 134.6c27.4 0 113.1-8.5 113.1 48.5 0 54.5-85.7 48.2-113.1 48.2l0-96.7zm0 251.8l0-106.5c32.8 0 133.1-9.1 133.1 53.3 0 60.2-100.4 53.3-133.1 53.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBtc = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;