'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'git';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f1d3';
var svgPathData = 'M216.3 158.4l-79.3 0c-40-10.5-130.5-7.8-130.5 74.8 0 30.1 15 51.2 35 61-25.1 23-37 33.8-37 49.2 0 11 4.5 21.1 17.9 26.8-14.3 13.4-22.4 23.1-22.4 41.4 0 32.1 28 50.8 101.6 50.8 70.8 0 111.8-26.4 111.8-73.2 0-58.7-45.2-56.5-151.6-63l13.4-21.6c27.3 7.6 118.7 10 118.7-67.9 0-18.7-7.7-31.7-15-41.1l37.4-2.8 0-34.5zM152.9 400.3c0 32.1-104.9 32.1-104.9 2.4 0-8.1 5.3-15 10.6-21.5 77.7 5.3 94.3 3.4 94.3 19.1zM102.1 265.7c-52.8 0-50.5-71.2 1.2-71.2 49.5 0 50.8 71.2-1.2 71.2zM235.4 366.2l0-32.1c26.7-3.7 27.2-2 27.2-11l0-119.5c0-8.5-2.1-7.4-27.2-16.3l4.5-32.9 84.2 0 0 168.7c0 6.5 .4 7.3 6.5 8.1l20.7 2.8 0 32.1-115.9 0zm52.5-244.3c-23.2 0-36.6-13.4-36.6-36.6s13.4-35.8 36.6-35.8c23.6 0 37 12.6 37 35.8s-13.4 36.6-37 36.6zM512 350.5c-17.5 8.5-43.1 16.3-66.3 16.3-48.4 0-66.7-19.5-66.7-65.5l0-106.5c0-5.4 1-4.1-31.7-4.1l0-36.2c35.8-4.1 50-22 54.5-66.3l38.6 0c0 65.8-1.3 61.8 3.3 61.8l57.3 0 0 40.6-60.6 0 0 97.1c0 6.9-4.9 51.4 60.6 26.8l11 35.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faGit = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;