'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'evernote';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'f839';
var svgPathData = 'M121.1 132.2c1.6 22.3-17.6 21.6-21.6 21.6-68.9 0-73.6-1-83.6 3.3-.6 .2-.7 0-.4-.4L124.1 46.4c.4-.4 .6-.2 .4 .4-4.4 10-3.4 15.1-3.4 85.4zm79 308c-14.7-37.1 13-76.9 52.5-76.6 17.5 0 22.6 23.2 7.9 31.4-6.2 3.3-24.9 1.7-25.1 19.2 0 17.1 19.7 25 31.2 24.9 6 0 11.9-1.2 17.5-3.5s10.6-5.7 14.8-9.9 7.6-9.3 9.9-14.8 3.5-11.5 3.5-17.5l0-.1c0-11.6-7.8-47.2-47.5-55.3-7.7-1.5-65-6.3-68.4-50.5-3.7 16.9-17.4 63.5-43.1 69.1-8.7 1.9-69.7 7.6-112.9-36.8 0 0-18.6-15.2-28.2-58-3.4-15.7-9.3-39.7-11.1-62 0-18 11.1-30.4 25.1-32.2 81 0 90 2.3 101-7.8 9.8-9.2 7.8-15.5 7.8-102.8 1-8.3 7.8-30.8 53.4-24.1 6 .9 31.9 4.2 37.5 30.6L290 74.8c20.4 3.7 70.9 7 80.6 57.9 22.7 121.1 8.9 238.5 7.8 238.5-16 114.4-111.1 108.9-111.1 108.9-19-.2-54.2-9.4-67.3-39.8l0 0zM281 235.4c-1 1.9-2.2 6 .9 7 14.1 4.9 39.8 6.8 45.9 5.5 3.1-.2 3.1-4.4 2.5-6.6-3.5-21.8-40.8-26.5-49.2-5.9l0 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faEvernote = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;