'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'bluetooth';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'f293';
var svgPathData = 'M260.6 171.1l-42.9 42.9-.3-86 43.2 43.1zM217.4 390.9l43.1-43.1-42.9-42.9-.2 86zM384 259.4C384 465 312.1 512 198.9 512S0 465 0 259.4 83.4 0 196.6 0 384 53.9 384 259.4zm-158.5 0l79.4-88.6-125.1-134.3 0 176.9-73.8-73.8-27 26.9 92.7 93-92.7 93 26.9 26.9 73.8-73.8 2.3 170 127.4-127.5-83.9-88.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBluetooth = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;