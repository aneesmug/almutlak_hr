'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'free-code-camp';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f2c5';
var svgPathData = 'M97.4 96.2c10.4-10.6 16-17.1 16-21.9 0-2.8-1.9-5.5-3.8-7.4-2.4-1.8-5.4-2.8-8.4-2.8-8.5 0-20.9 8.8-35.8 25.7-41.5 47.3-62.7 93.1-61.8 160.6S21 367.3 57.6 412.2c18.8 23.6 33.2 35.8 43.5 35.8 3.2-.3 6.1-1.6 8.4-3.8 1.9-2.8 3.8-5.6 3.8-8.4 0-5.6-3.9-12.2-13.2-20.6-44.5-42.3-67.3-97-67.5-165-.2-61.4 21.6-112.4 64.8-154zM239.6 420.1c.6 .4 .9 .6 .9 .6l-.9-.6zm93.8 .6l.2-.1c-.2 .1-.3 .2-.2 .1zm3.1-158.2c-16.2-4.2 50.4-82.9-68.1-177.2 0 0 15.5 49.4-62.8 159.6-74.3 104.4 23.5 168.7 34 175.2-6.7-4.3-47.4-35.7 9.6-128.6 11-18.3 25.5-34.9 43.5-72.2 0 0 15.9 22.4 7.6 71.1-12.5 73.6 53.8 52.5 54.8 53.5 22.8 26.8-17.7 73.5-21.6 76.6 5.5-3.7 117.7-78 33-188.1-6 6-13.8 34.2-30 30.1zM511 89.7c-14.9-16.9-27.4-25.7-35.9-25.7-3 .1-5.9 1.1-8.4 2.8-1.9 1.9-3.8 4.7-3.8 7.4 0 4.8 5.6 11.3 16 21.9 43.2 41.6 65 92.6 64.8 154.1-.2 68-23 122.6-67.5 165-9.3 8.4-13.2 14.9-13.2 20.6 0 2.7 1.9 5.6 3.8 8.4 2.3 2.2 5.2 3.6 8.4 3.8 10.3 0 24.7-12.1 43.5-35.8 36.6-44.9 53.1-94.4 54.1-161.9S552.5 137 511 89.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFreeCodeCamp = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;