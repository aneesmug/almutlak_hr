'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'gofore';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f3a7';
var svgPathData = 'M348 319.8l-13.2 0 0 34.7c-24.5 23.1-56.3 35.8-89.9 35.8-73.2 0-132.4-60.2-132.4-134.4 0-74.1 59.2-134.4 132.4-134.4 35.3 0 68.6 14 93.6 39.4l62.3-63.3c-41.8-42.3-97.1-65.6-156.1-65.6-122.7 0-220.7 100.6-220.7 224 0 122.5 97 224 220.7 224 63.2 0 124.5-26.2 171-82.5-2-27.6-13.4-77.7-67.7-77.7zM335.9 207.3l-106.3 0 0 89 118.4 0c33.5 0 60.5 15.1 76 41.8l0-30.6c0-65.2-40.4-100.2-88.1-100.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faGofore = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;