'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'cotton-bureau';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f89e';
var svgPathData = 'M474.3 330.4C450.6 422.3 380.1 475 272.4 478.8l0-49.2c0-48 26.4-74.4 74.4-74.4 62 0 99.2-37.2 99.2-99.2 0-61.4-36.5-98.3-97.4-99.1-33-69.3-146.5-64.7-177.2 0-60.9 .8-97.4 37.7-97.4 99.1 0 62.1 37.3 99.4 99.4 99.4 48 0 74.6 26.2 74.6 74.4l0 49.2c-134.4-5-211.1-85.1-211.1-223 0-141.8 81.4-223.2 223.2-223.2 114.8 0 189.8 53.2 214.7 148.8l25.3 0C473.9 71.5 388.2 8 259.8 8 105 8 12 101.2 12 255.8 12 411.1 105.2 504.3 259.8 504 388.1 504 473.7 440.2 499.5 330.4l-25.2 0zM357 182.3c41.4 3.4 64.2 29 64.2 73.7 0 48-26.4 74.4-74.4 74.4-28.6 0-49.3-9.6-61.6-27.3 83.1-16.5 75.6-99.7 71.8-120.7zm-81.7 97.4c-2.5-10.3-16.3-87 56.2-97 2.3 10.1 16.5 87.1-56.3 97l0 0zM260 132c28.6 0 49 9.7 61.4 27.6-28.4 5.5-49.4 20.6-61.6 43.4-12.2-22.9-33.2-38-61.6-43.4 12.4-17.7 33.3-27.4 61.6-27.4l.2-.3zm-71.5 50.7c73.2 10.6 58.9 86.8 56.5 97-72.4-9.8-59-87-56.2-97l-.2 0zM173.2 330.4c-48 0-74.4-26.4-74.4-74.4 0-44.4 22.9-70 64.2-73.7-6.8 37.2-1.4 106.5 71.6 120.7-12.1 17.6-32.8 27.3-61.1 27.3l-.3 0zm53.2 12.4c14.3-7.6 26-19.3 33.6-33.5 7.8 14.5 19.3 25.5 33.8 33.5-14.4 7.6-26.1 19.4-33.6 33.8-8-14.5-19.1-26.2-33.6-33.8l-.3 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCottonBureau = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;