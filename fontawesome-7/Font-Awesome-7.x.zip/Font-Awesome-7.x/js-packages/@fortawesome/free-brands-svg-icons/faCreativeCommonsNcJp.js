'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'creative-commons-nc-jp';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f4ea';
var svgPathData = 'M255.7 8C111.6 8 8 124.8 8 256 8 392.4 119.8 504 255.7 504 385.9 504 504 403.2 504 256 504 117.2 396.5 8 255.7 8zm.6 450.7c-112 0-203.6-92.5-203.6-202.7 0-21.1 3-41.2 9-60.3l127 56.5-27.9 0 0 38.6 58.1 0 5.7 11.8 0 18.7-63.8 0 0 38.7 63.8 0 0 56 61.7 0 0-56 64.2 0 0-35.7 81 36.1c-1.5 2.2-57.1 98.3-175.2 98.3zm87.6-137.3l-57.6 0 0-18.7 2.9-5.6 54.7 24.3zm6.5-51.4l0-17.8-38.6 0 63-116-65.8 0-43.4 96-23-10.2-39.6-85.7-65.8 0 27.3 51-81.9-36.5c27.8-44.1 82.6-98.1 173.7-98.1 112.8 0 203 90 203 203.4 0 21-2.7 40.6-7.9 59L350.4 270z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCreativeCommonsNcJp = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;