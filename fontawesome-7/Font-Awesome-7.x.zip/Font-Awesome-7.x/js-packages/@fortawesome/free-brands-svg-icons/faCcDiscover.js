'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'cc-discover';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f1f2';
var svgPathData = 'M520.4 196.1c0-7.9-5.5-12.1-15.6-12.1l-4.9 0 0 24.9 4.7 0c10.3 0 15.8-4.4 15.8-12.8zM528 32L48 32C21.5 32 0 53.5 0 80L0 432c0 26.5 21.5 48 48 48l480 0c26.5 0 48-21.5 48-48l0-352c0-26.5-21.5-48-48-48zM483.9 170.9c22.6 0 52.9-4.1 52.9 24.4 0 12.6-6.6 20.7-18.7 23.2l25.8 34.4-19.6 0-22.2-32.8-2.2 0 0 32.8-16 0 0-82zM428 171l45.3 0 0 14-29.3 0 0 18.2 28.3 0 0 13.8-28.3 0 0 22.2 29.3 0 0 13.8-45.3 0 0-82zm-68.7 0l21.9 55.2 22.2-55.2 17.5 0-35.5 84.2-8.6 0-35-84.2 17.5 0zm-55.9 86.2a44.6 44.6 0 1 1 0-89.2 44.6 44.6 0 1 1 0 89.2zm-49.3-83.1l0 19c-20.1-20.1-46.8-4.7-46.8 19 0 25 27.5 38.5 46.8 19.2l0 19c-29.7 14.3-63.3-5.7-63.3-38.2 0-31.2 33.1-53 63.3-38zm-97.2 66.3c11.4 0 22.4-15.3-3.3-24.4-15-5.5-20.2-11.4-20.2-22.7 0-23.2 30.6-31.4 49.7-14.3l-8.4 10.8c-10.4-11.6-24.9-6.2-24.9 2.5 0 4.4 2.7 6.9 12.3 10.3 18.2 6.6 23.6 12.5 23.6 25.6 0 29.5-38.8 37.4-56.6 11.3l10.3-9.9c3.7 7.1 9.9 10.8 17.5 10.8zM55.4 253l-23.4 0 0-82 23.4 0c26.1 0 44.1 17 44.1 41.1 0 18.5-13.2 40.9-44.1 40.9zm67.5 0l-16 0 0-82 16 0 0 82zM544 433c0 8.2-6.8 15-15 15l-401 0c189.6-35.6 382.7-139.2 416-160l0 145zM74.1 191.6c-5.2-4.9-11.6-6.6-21.9-6.6l-4.2 0 0 54.2 4.2 0c10.3 0 17-2 21.9-6.4 5.7-5.2 8.9-12.8 8.9-20.7s-3.2-15.5-8.9-20.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCcDiscover = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;