'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'creative-commons-nc-eu';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f4e9';
var svgPathData = 'M255.7 8C111.6 8 8 124.8 8 256 8 392.3 119.7 504 255.7 504 385.9 504 504 403.1 504 256 504 117 396.4 8 255.7 8zm.6 450.7c-112 0-203.6-92.5-203.6-202.7 0-23.2 3.7-45.2 10.9-66l65.7 29.1-4.7 0 0 29.5 23.3 0c0 6.2-.4 3.2-.4 19.5l-22.8 0 0 29.5 27 0c11.4 67 67.2 101.3 124.6 101.3 26.6 0 50.6-7.9 64.8-15.8l-10-46.1c-8.7 4.6-28.2 10.8-47.3 10.8-28.2 0-58.1-10.9-67.3-50.2l90.3 0 128.3 56.8c-1.5 2.1-56.2 104.3-178.8 104.3zM239.6 268.1l-.5-.4 .9 .4-.4 0zm77.2-19.5l3.7 0 0-29.5-70.3 0-28.6-12.6c2.5-5.5 5.4-10.5 8.8-14.3 12.9-15.8 31.1-22.4 51.1-22.4 18.3 0 35.3 5.4 46.1 10l11.6-47.3c-15-6.6-37-12.4-62.3-12.4-39 0-72.2 15.8-95.9 42.3-5.3 6.1-9.8 12.9-13.9 20.1L85.5 146.4c64.6-96.8 157.7-93.6 170.7-93.6 113 0 203 90.2 203 203.4 0 18.7-2.1 36.3-6.3 52.9L316.8 248.6z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCreativeCommonsNcEu = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;