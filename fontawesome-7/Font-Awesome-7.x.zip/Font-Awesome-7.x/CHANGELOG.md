# Change Log

Font Awesome 7 is here! And with it a new location for the change log.

Visit https://fontawesome.com/docs/changelog/.
